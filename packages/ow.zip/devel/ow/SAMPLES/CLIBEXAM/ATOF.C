#include <stdlib.h>

void main()
  {
    double x;

    x = atof( "3.1415926" );
  }
