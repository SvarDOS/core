#include <stdlib.h>

void main()
  {
    long int v;

    v = strtol( "12345678", NULL, 10 );
  }
