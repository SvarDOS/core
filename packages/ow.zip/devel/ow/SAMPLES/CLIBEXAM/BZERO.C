#include <string.h>

void main()
  {
    char buffer[80];

    bzero( buffer, 80 );
  }
