#include <stdio.h>
#include <time.h>

void main()
  {
    char datebuff[9];

    printf( "%s\n", _strdate( datebuff ) );
  }
