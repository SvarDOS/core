#include <stdlib.h>
#include <malloc.h>

void main()
  {
    _heapmin();
    system( "chdir c:\\watcomc" );
  }
