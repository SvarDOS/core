#include <stdlib.h>

void main()
  {
    unsigned long int v;

    v = strtoul( "12345678", NULL, 10 );
  }
