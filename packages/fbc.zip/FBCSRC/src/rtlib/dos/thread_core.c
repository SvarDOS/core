/* thread creation and destruction functions */

#include "../fb.h"

FBCALL FBTHREAD *fb_ThreadCreate( FB_THREADPROC proc, void *param, ssize_t stack_size )
{
	return NULL;
}

FBCALL void fb_ThreadWait( FBTHREAD *thread )
{
}
