FBCALL FBSTRING    *fb_LCASE            ( FBSTRING *src );
FBCALL FBSTRING    *fb_UCASE            ( FBSTRING *src );

FBCALL FB_WCHAR    *fb_WstrLcase        ( const FB_WCHAR *src );
FBCALL FB_WCHAR    *fb_WstrUcase        ( const FB_WCHAR *src );
